<?php 
$dbservername="localhost";
$dbusername="root";
$dbpassword="";
$dbdatabase="ajar_prak";

$konek=mysqli_connect($dbservername,$dbusername,$dbpassword,$dbdatabase);


?>



