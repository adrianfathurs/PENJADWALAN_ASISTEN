<?php
include "koneksi.php";
$id=$_POST['edit'];
$nama=$_POST['namaasisten'];
$hari=$_POST['hari'];
$waktu=$_POST['waktu']

$query=mysqli_query($konek,"UPDATE dataasisten a,jadwalmengajar j SET j.id_asisten,a.nama_asisten,j.hari,j.waktu where a.id_asisten='$id' );
?>