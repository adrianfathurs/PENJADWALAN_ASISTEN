-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 31, 2019 at 05:30 PM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ajar_prak`
--

-- --------------------------------------------------------

--
-- Table structure for table `dataasisten`
--

CREATE TABLE `dataasisten` (
  `id_asisten` int(11) NOT NULL,
  `nama_asisten` varchar(30) NOT NULL,
  `nim` varchar(9) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dataasisten`
--

INSERT INTO `dataasisten` (`id_asisten`, `nama_asisten`, `nim`) VALUES
(1, 'Dika Mahrdika', '123170061'),
(2, 'Anisa Fitri', '123170090'),
(3, 'Anisa Dzunurain', '123170051'),
(4, 'Adrian Fathur Setyawan', '123170018');

-- --------------------------------------------------------

--
-- Table structure for table `jadwalmengajar`
--

CREATE TABLE `jadwalmengajar` (
  `id_jadwal` int(11) NOT NULL,
  `id_asisten` int(11) NOT NULL,
  `lab` varchar(20) NOT NULL,
  `hari` varchar(15) NOT NULL,
  `waktu` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jadwalmengajar`
--

INSERT INTO `jadwalmengajar` (`id_jadwal`, `id_asisten`, `lab`, `hari`, `waktu`) VALUES
(25, 2, 'Lab Geoinformatika', 'kamis', '08.00-10.00'),
(27, 1, 'lab Jaringan', 'Senin', '12.00-15.00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `dataasisten`
--
ALTER TABLE `dataasisten`
  ADD PRIMARY KEY (`id_asisten`);

--
-- Indexes for table `jadwalmengajar`
--
ALTER TABLE `jadwalmengajar`
  ADD PRIMARY KEY (`id_jadwal`),
  ADD KEY `fk_id_asisten` (`id_asisten`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `dataasisten`
--
ALTER TABLE `dataasisten`
  MODIFY `id_asisten` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `jadwalmengajar`
--
ALTER TABLE `jadwalmengajar`
  MODIFY `id_jadwal` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `jadwalmengajar`
--
ALTER TABLE `jadwalmengajar`
  ADD CONSTRAINT `fk_id_asisten` FOREIGN KEY (`id_asisten`) REFERENCES `dataasisten` (`id_asisten`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
