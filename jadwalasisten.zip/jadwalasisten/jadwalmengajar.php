<?php 
include "koneksi.php";
?>

<!DOCTYPE html>
<html>
<head>
	<title>Data Asisten</title>
	<!-- BOOSTRAPS -->
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<!-- JAVA SCRIPT BOOSTRAPS -->
	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>

</head>

<style type="text/css">
	.container{
		margin-left: 400px;
		
	}
	.h1{
		margin-bottom: 30px;
	}
	.jarak{
		margin-top: 50px;
		margin-left: 180px;
	}
	.logo3{
		width:50px;
		height:50px;
	}
	.footer{
    color:  #F5FFFA;
    margin-top: 30px;
  }
  .jumbotron{
		background:url(img/bendera.jpg);
		width: 600;
		height:400 ;
		position: relative;
		background-size: cover;
		overflow: hidden;
	}
	.mg-rightdownlm{
		margin-left: 520px;
		margin-top: 50px;

	}
  .text-dftr{
    font-family: Impact, Charcoal, sans-serif;
  }
  .text{
		font-family: "Comic Sans MS", cursive;
		color: 	#00CED1;
	}
	.jarak-2{
		margin-top: 50px;
		margin-left: 30px;	
	}
</style>

<body>
	<!-- NAVBAR BOOTSTRAP -->
	<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
	  <a class="navbar-brand" href="#"><img class="logo3" src="logo3.jpg"></a>
	  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
	    <span class="navbar-toggler-icon"></span>
	  </button>

	  <div class="collapse navbar-collapse" id="navbarSupportedContent">
	    <ul class="navbar-nav mr-auto">
	      <li class="nav-item active">
	        <a class="nav-link" href="tampil.php">TAMPIL DATA <span class="sr-only">(current)</span></a>
	      </li>
	      <li class="nav-item">
	        <a class="nav-link" href="dataasisten.php">DATA ASISTEN<span class="sr-only">(current)</span></a>
	      </li><li class="nav-item">
	        <a class="nav-link" href="jadwalmengajar.php">JADWAL MENGAJAR<span class="sr-only">(current)</span></a>
	      </li>
	  	</ul>
	  </div>
	</nav>
<!-- JUMBOTRON -->
	<div class="jumbotron jumbtron-fluid">
  		<center><h1 class="display-4 text">HAPPY EDUCATION'S DAY</h1>
  		<p class="lead text">"I always study until my life is end up"</p></center>  
  		<a class="btn btn-outline-warning btn-lg mg-rightdownlm" href="#" role="button">Learn more</a>
	</div>
		<!-- HEADER  -->
		<center><h1>INPUT JADWAL MENGAJAR</h1></center>



	<!-- BUAT FORM INPUT MENGGUNAKAN SELECT AMBIL DATA -->
	<div class="container">
	<form method="POST" action="rekamdataasisten.php" >
	<!-- NAMA ASISTEN -->	
	<div class="form-group row">
    <label for ="namaasisten" class="col-sm-2 col-form-label">NAMA ASISTEN</label>
    <div class="col-sm-3">
     <select id="id_asisten" name="namaasisten"class="form-control ">
			<?php
			$query=mysqli_query($konek,"SELECT id_asisten,nama_asisten FROM dataasisten");
			while ($data=mysqli_fetch_assoc($query)) {?>
				<option values="<?php echo $data['id_asisten'];?>"><?php echo $data['nama_asisten']; ?></option>	
			<?php
				}
			?>
		</select>
    </div>
  </div>
	<!--LAB  -->
	<div class="form-group row">
    <label for ="lab" class="col-sm-2 col-form-label">LABORATORIUM</label>
    <div class="col-sm-3">
     <select id="lab" name="lab"class="form-control ">
			<?php
			$query=mysqli_query($konek,"SELECT distinct lab FROM jadwalmengajar");
			while ($data=mysqli_fetch_assoc($query)) {?>
				<option values="<?php echo $data['lab'];?>"><?php echo $data['lab']; ?></option>	
			<?php
				}
			?>
		</select>
    </div>
  </div>
  <!--Hari  -->
	<div class="form-group row">
    <label for ="hari" class="col-sm-2 col-form-label">HARI</label>
    <div class="col-sm-3">
     <select id="hari" name="hari"class="form-control ">
			<?php
			$query=mysqli_query($konek,"SELECT distinct hari FROM jadwalmengajar");
			while ($data=mysqli_fetch_assoc($query)) {?>
				<option values="<?php echo $data['hari'];?>"><?php echo $data['hari']; ?></option>	
			<?php
				}
			?>
		</select>
    </div>
  </div>
  <!--waktu  -->
	<div class="form-group row">
    <label for ="waktu" class="col-sm-2 col-form-label">WAKTU</label>
    <div class="col-sm-3">
     <select id="waktu" name="waktu"class="form-control ">
			<?php
			$query=mysqli_query($konek,"SELECT distinct waktu FROM jadwalmengajar");
			while ($data=mysqli_fetch_assoc($query)) {?>
				<option values="<?php echo $data['waktu'];?>"><?php echo $data['waktu']; ?></option>	
			<?php
				}
			?>
		</select>
    </div>
  </div>
  <!-- button Submit -->
  <input type="submit" value="SUBMIT" class="btn btn-outline-warning jarak" name="kirim">
  <input type="submit" value="HAPUS" class="btn btn-outline-warning jarak-2" name="kirim">
 
	</form>
</div>
<center><footer class="bg-dark"><div class="footer"><p>INFORMATIKA 2017</p>
                <p> &copy copyright</p></div>
</footer></center>
</body>
</html>