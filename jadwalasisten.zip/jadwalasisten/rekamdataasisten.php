<?php
include "koneksi.php"; 

$nama=$_POST['namaasisten'];
$lab=$_POST['lab'];
$hari=$_POST['hari'];
$waktu=$_POST['waktu'];
$kirim=$_POST['kirim'];
//echo $nama." ".$lab." ".$hari." ".$waktu." ".$kirim;
$benar="false";

if($_POST['kirim']=="SUBMIT"){
$query=mysqli_query($konek,"SELECT id_asisten,nama_asisten FROM dataasisten");
while ($data=mysqli_fetch_assoc($query)){
	if($data['nama_asisten']==$_POST['namaasisten'])
	{ //mengkoncvert nama asisten dengan id agar syarat kolom database terpenuhi
		$id=$data['id_asisten'];
		$hasil=mysqli_query($konek,"INSERT INTO jadwalmengajar values('','$id','$lab','$hari','$waktu')")or die (mysqli_error($hasil));	
		echo include "tampil.php";		
	}
  }
}

else if($_POST['kirim']=="HAPUS"){
$query=mysqli_query($konek,"SELECT j.hari,j.id_jadwal,a.nama_asisten FROM dataasisten a,jadwalmengajar j where a.id_asisten=j.id_asisten");
while ($data=mysqli_fetch_assoc($query)){
	if($data['nama_asisten'] == $_POST['namaasisten'] && $data['hari'] == $_POST['hari'])
	{ //mengkoncvert nama asisten dengan id agar syarat kolom database terpenuhi
		$id=$data['id_jadwal'];
		//echo $id;
		$hasil=mysqli_query($konek,"DELETE from jadwalmengajar where id_jadwal='$id'")or die (mysqli_error($hasil));
		echo include "tampil.php";
		$benar="true";
	}
	
}
	if($benar!="true"){
		echo include "notfounddata.html";
	}
}

else {
	echo include "notfounddata.html";
}


?>