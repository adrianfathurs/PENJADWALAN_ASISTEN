<?php 
include "koneksi.php";

 function namaasisten()
 {

			$query=mysqli_query($konek,"SELECT id_asisten,nama_asisten FROM dataasisten");
			while ($data=mysqli_fetch_assoc($query)) {?>
				<option values="<?php echo $data['id_asisten'];?>"><?php echo $data['nama_asisten']; ?></option>	
			
			<?php }
			
 }

?>